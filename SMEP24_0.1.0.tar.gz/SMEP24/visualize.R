library(SMEP24)

setwd("D:\\Reduc_Control")

fileNames <- list.files(pattern=".csv")
df <- lapply(fileNames, function(x)fread(x, data.table=FALSE))
names(df) <- fileNames
gatheredInfo <- lapply(strsplit(fileNames, split="_"), function(x)gsub(".csv", "", x))

p <- ggplot(data=df[[1]], aes(x=rhat))+
  geom_density(fill="gray")+
  theme_apa()
